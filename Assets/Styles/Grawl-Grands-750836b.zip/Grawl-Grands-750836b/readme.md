# Grands
## Social icon font

[![No Maintenance Intended](http://unmaintained.tech/badge.svg)](http://unmaintained.tech/)

### Набор значков для серьёзных проектов
В основу лёг [набор значков от Hands-Creative](http://hands-creative.com/icon/), затем были выброшены ненужные значки и значки сервисов mail.ru.
Набор предоставляется в исключительно векторных форматах: в шрифте и россыпью файлов SVG.

###[Быстрый старт](http://grawl.github.com/Grands/)

Нравится формат, но нет нужного значка? [Создай Issue](https://github.com/Grawl/Grands/issues/new).

*Шрифт создан при помощи [IcoMoon](http://icomoon.io/).*

Лицензия — [WTFPL](http://ru.wikipedia.org/wiki/WTFPL)
